package br.com.etechoracio.ProjectEtec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectEtecApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectEtecApplication.class, args);
	}

}
